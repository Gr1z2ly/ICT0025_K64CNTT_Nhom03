<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>nv3_for</title>
</head>
<body>
    <?php
    $soLuong = 5;

    for ($i = 1; $i <= $soLuong; $i++) {
        echo "Công việc " . $i . "<br>\n";
    }
    ?>
</body>
</html>
